function sendMessage() {
  const input = document.getElementById('userInput');
  const message = input.value.trim();
  if (!message) return;

  const messages = document.getElementById('messages');
  messages.innerHTML += `<div><b>You:</b> ${message}</div>`;
  input.value = '';

  fetch('/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message })
  })
    .then(res => res.json())
    .then(data => {
      messages.innerHTML += `<div><b>Bot:</b> ${data.reply}</div>`;
      messages.scrollTop = messages.scrollHeight;
    })
    .catch(() => {
      alert('Failed to send message.');
    });
}

// Load recent history on page load
window.onload = () => {
  const messages = document.getElementById('messages');
  messages.innerHTML = `<div class="chat-slogan">Wish it. Chat it. Do it — with WishKey.</div>`;
  fetch('/history')
    .then(res => res.json())
    .then(chats => {
      chats.reverse().forEach(chat => {
        messages.innerHTML += `<div><b>You:</b> ${chat.userMessage}</div>`;
        messages.innerHTML += `<div><b>Bot:</b> ${chat.botResponse}</div>`;
      });
      messages.scrollTop = messages.scrollHeight;
    })
    .catch(() => {
      alert('Failed to load chat history.');
    });
};



function viewChatHistory() {
  fetch('/history')
    .then(res => res.json())
    .then(chats => {
      const messages = document.getElementById('messages');
      messages.innerHTML = `<div class="chat-slogan">Wish it. Chat it. Do it — with WishKey.</div>`;
      chats.reverse().forEach(chat => {
        messages.innerHTML += `<div><b>You:</b> ${chat.userMessage}</div>`;
        messages.innerHTML += `<div><b>Bot:</b> ${chat.botResponse}</div>`;
      });
      messages.scrollTop = messages.scrollHeight;
    })
    .catch(() => {
      alert('Failed to load chat history.');
    });
}

function deleteChatHistory() {
  fetch('/delete-history', { method: 'DELETE' })
    .then(res => {
      if (res.ok) {
        const messages = document.getElementById('messages');
        messages.innerHTML = '';
        alert('Chat history deleted.');
      } else {
        alert('Failed to delete chat history.');
      }
    })
    .catch(() => {
      alert('Failed to delete chat history.');
    });
}
